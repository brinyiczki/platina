#!/sbin/sh
###########################################
# Last Updated : 2022, April 19
###########################################
#

##### PREDEFINED COMPONENTS #####

ui_print() {
  echo "ui_print $1" > "$OUTFD";
  echo "ui_print" > "$OUTFD";
}

set_progress() { echo "set_progress $1" > "$OUTFD"; }

TMP="/tmp"

set_progress 0.10;

##### UMOUNT PARTITITIONS #####

# Ensure partitions are unmounted so mounting succeeds
umount /system
umount /system_root
umount /vendor

##### DETECT PARTITIONS #####

ui_print "MOUNTING PARTITIONS"

system_as_root=`getprop ro.build.system_root_image`
active_slot=`getprop ro.boot.slot_suffix`
dynamic=`getprop ro.boot.dynamic_partitions`

ui_print "| Detecting Partition Layout";

if [ "$dynamic" = "true" ]; then
    ui_print "| Dynamic partition detected";
    if [ ! -z "$active_slot" ]; then
        system_block=/dev/block/mapper/system$active_slot
        vendor_block=/dev/block/mapper/vendor$active_slot
            else
        system_block=/dev/block/mapper/system
        vendor_block=/dev/block/mapper/vendor
    fi
    ui_print "| System: $system_block";
    ui_print "| Vendor: $vendor_block";
    blockdev --setrw $system_block
	blockdev --setrw $vendor_block
        else
    if [ ! -z "$active_slot" ]; then
        system_block=`cat /etc/recovery.fstab | grep -o '/dev/[^ ]*system' | cut -f -1 | head -1`$active_slot
        vendor_block=`cat /etc/recovery.fstab | grep -o '/dev/[^ ]*vendor' | cut -f -1 | head -1`$active_slot
            else
        system_block=`cat /etc/recovery.fstab | grep -o '/dev/[^ ]*system' | cut -f -1 | head -1`
        vendor_block=`cat /etc/recovery.fstab | grep -o '/dev/[^ ]*vendor' | cut -f -1 | head -1`
    fi
    ui_print "| System: $system_block";
    ui_print "| Vendor: $vendor_block";
    blockdev --setrw $system_block
	blockdev --setrw $vendor_block
fi

sleep 0.5;


##### MOUNT SYSTEM #####

mkdir -p /system
mkdir -p /system_root
if mount -o rw $system_block /system_root; then
	if [ -e /system_root/build.prop ]; then
		MOUNTED=/system_root
		ui_print "| System as system detected!";
			else
		MOUNTED=/system_root/system
		ui_print "| System as root detected!";
	fi
	sleep 0.5;
	mount -o bind $MOUNTED /system
	SYSTEM=/system
	ui_print "| System successfully binded!";
  else
    ui_print " "
    ui_print "ERROR >>> Couldn't mount SYSTEM! Aborting";
    ui_print " "
    umount -l /system && umount -l /system_root
    exit 1
fi


##### MOUNT VENDOR #####

if [ ! -z $vendor_block ]; then
    if mount -o rw $vendor_block /vendor; then
        ui_print "| Vendor successfully mounted!";
        VENDOR=/vendor''
            else
        ui_print " "
        ui_print "ERROR >>> Couldn't mount VENDOR! Aborting";
        ui_print " "
        exit 1
    fi
        else
    VENDOR=/system/vendor
    ui_print "| Using /system/vendor";
fi

sleep 0.5;
set_progress 0.20;

##### LIBRARY PATH #####

OLD_LD_LIB=$LD_LIBRARY_PATH
OLD_LD_PRE=$LD_PRELOAD
OLD_LD_CFG=$LD_CONFIG_FILE
unset LD_LIBRARY_PATH
unset LD_PRELOAD
unset LD_CONFIG_FILE

set_progress 0.30;
sleep 0.5;

##### RW TEST #####

ui_print " ";
ui_print "TEST RW";
if touch $SYSTEM/testofile ; then
    ui_print "| Successfully touch system test file";
    rm $SYSTEM/testofile
        else
    ui_print "| System RO or not enough free space";
    exit 1
fi

if touch $VENDOR/testofile ; then
    ui_print "| Successfully touch vendor test file";
    rm $VENDOR/testofile
        else
    ui_print "| Vendor RO or not enough free space";
    exit 1
fi

##### DISABLE ENCRYPTION #####

ui_print " ";
ui_print "DO THINGS";
fstabs="$(find $VENDOR/etc -type f \( -name "fstab*" -o -name "*.fstab" \) | sed "s|^./||")"

android_sdk=`cat /system/build.prop | grep -o 'ro.system.build.version.sdk[^ ]*' | cut -c 29-30`
ui_print "| SDK: $android_sdk";

for file in $fstabs; do
        ui_print "| Detected and modifying $file"
        cp -a $file "$file".bak

        sed -ir 's|fileencryption|encryptable|' "$file"
        sed -ir 's|forceencrypt|encryptable|' "$file"
        sed -ir 's|forcefdeorfbe|encryptable|' "$file"
        sed -ir 's|,wrappedkey||' "$file"
        sed -ir 's|,avb=vbmeta_system,avb_keys=/avb/q-gsi.avbpubkey:/avb/r-gsi.avbpubkey:/avb/s-gsi.avbpubkey||' "$file"
        sed -ir 's|,avb=vbmeta_system||' "$file"
        sed -ir 's|,support_scfs||' "$file"
        sed -ir 's|,fsverity||' "$file"
        sed -ir 's|,verifyatboot||' "$file"
        sed -ir 's|,verity||' "$file"
        sed -ir 's|,avb||' "$file"
        sed -ir 's|,quota||' "$file"
        sed -ir 's|,errors=panic||' "$file"
        
        if [ "$android_sdk" -ge "33" ]; then
            sed -ir 's|encryptable=||' "$file"
            sed -ir 's|encryptable=||' "$file"
            sed -ir 's|encryptable=||' "$file"
        fi
done

set_progress 0.80;
sleep 0.5;

##### UMOUNT PARTITIONS #####

ui_print " ";
ui_print "UNMOUNTING PARTITIONS";
if umount -l /system; then
	ui_print "| Successfully unmounted /system";
		else
	ui_print "| Couldn't unmount /system";
fi

if umount -l /system_root; then
	ui_print "| Successfully unmounted /system_root";
		else
	ui_print "| Couldn't unmount /system_root";
fi

if [ "$VENDOR" = /vendor ]; then
  if umount -l /vendor; then
	  ui_print "| Successfully unmounted /vendor";
		  else
	  ui_print "| Couldn't unmount /vendor";
  fi
fi

##### RESET LIBRARY PATH #####

sleep 1.0
[ -z $OLD_LD_LIB ] || export LD_LIBRARY_PATH=$OLD_LD_LIB
[ -z $OLD_LD_PRE ] || export LD_PRELOAD=$OLD_LD_PRE
[ -z $OLD_LD_CFG ] || export LD_CONFIG_FILE=$OLD_LD_CFG
ui_print "| Enjoy";
ui_print " ";
set_progress 1.00;